package com.example.cr1.explicitindent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
private Button send1;
private EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        send1 =findViewById(R.id.button);
        editText=findViewById(R.id.editText2);
    }

public void send(View v)
{
    String data=editText.getText().toString();
    Intent intent=new Intent(this,login.class);
    intent.putExtra("email",data.toString());

    startActivity(intent);
}
}
