package com.example.cr1.explicitindent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class login extends AppCompatActivity {
private TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        t=findViewById(R.id.text);
        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            String name1 = extras.getString("email");
            Toast.makeText(getApplicationContext(),""+name1,Toast.LENGTH_LONG).show();
            t.setText(name1);

        }

    }
}
